#
#
# JDBC Distributive example
#
#
# $Id$ 

Scenario:
---------
The JDBC Distributive example is a simple example showing how
to use JTA transactions with two JDBC databases.

Setup:
------
o JOTM is the Transaction Manager, including the registry.
o A database, for example:
	- MySQL
	- PostgreSQL
    - Oracle

o DistDatabaseHelper setups the JDBC objects (i.e., the JDBC Connections) with Enhydra
  wrappers and associates them to JOTM as their transaction manager.

o JdbcDistExample then will ask the DistDatabaseHelper for two connections, update a table
  in two different databases within a transaction and complete this transaction thanks to
  arguments given by the user.

Database Setup:
---------------

The example expects:
o a database named javatest for each host name
  If using localhost, define two databases named
  javatest1 and javatest2
  Change the SQL commands in the java code to reference
  the javatest1 and javatest2 databases
o a user of login "mojo" and password "jojo"
o a *transactional* table named testdata which is like 

+----+-------+
| ID | FOO   |
+----+-------+
|  1 | 1     |
+----+-------+
	
	o id being an int (primary key)
	o foo being an int
	
For example on MySQL:

$$$    Note: Use below for javatest1 and repeat for javatest2   $$$
# mysql -u root
mysql> grant all privileges on *.* to 'mojo'@'localhost' identified by 'jojo' with grant option;
mysql> grant all privileges on *.* to 'mojo'@'%' identified by 'jojo' with grant option;
mysql> exit

$ mysql -u mojo -p
mysql> create database javatest1;
mysql> use javatest1;
mysql> create table testdata (id int not null auto_increment primary key,foo int)type=InnoDB;
mysql> insert into testdata values(null, 1);
mysql> exit

Database configuration are stored in properties file (mysql1.propertiesand mysql2.properties,
postgresql1.properties and postgress2.properties, and oracle1.properties and oracle2.properties)
which contains the following properties:
o driver - Name of the JDBC driver
o url - URL to connect to the data base
o login - user login
o password - user password 

You must install the Driver in $JOTM_HOME/lib, for example:
$JOTM_HOME/lib/mysql-connector-java-5.1.6-bin.jar

Compilation:
------------

Set JOTM_HOME to the directory of your JOTM distribution

In the  JOTM_HOME/examples/jdbc directory type:

     ant compile

to compile the example

Running the JDBC example: (example with the jrmp protocol)
----------------------------------------------------------
Configure the carol.properties: ($JOTM_HOME/conf/carol.properties)

  carol.protocols=jrmp or iiop
  carol.start.ns=true or false

Start the jotm:
- adapt $JOTM_HOME/bin/jotm depending on the carol options.
- start the jotm:
$ jotm

o Start the example:
-------------------
Adapt the script run-example.sh, mainly to choose which database you want to use.
Run it:
$ run-example.sh

o Of course you can mix databases
